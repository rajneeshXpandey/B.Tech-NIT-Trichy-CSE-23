# dbmsLab12

follow the tutorial for making php work for mongodb & also for downloading composer file:

https://www.youtube.com/watch?v=9gEPiIoAHo8&list=PLC3y8-rFHvwiXX1maB5o-CZAIHy4I_ILv&index=1

[
download threadsafe x64 from:
https://pecl.php.net/package/mongodb/1.11.1/windows
as shown in the tutorial

add the mongodb.dll file into mongodb/php/ext folder as shown in the tutorial
]

Run xampp and mongodb

create a database billing and 4 tables - cashier, customer, product, transaction in mongodb

To run the project go to localhost/[your folder name]/index.php
